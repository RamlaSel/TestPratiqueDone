package com.connexence.testPratique;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestPratiqueApplicationTests {

	@Test
	void contextLoads() {
	}

}
